SELECT *
FROM patients_1527
WHERE conditions LIKE '% DIAB1%' OR conditions LIKE 'DIAB1%';
