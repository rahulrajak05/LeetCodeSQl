SELECT COUNT(DISTINCT customer_id) AS rich_count
FROM store_2082
WHERE amount > 500;
