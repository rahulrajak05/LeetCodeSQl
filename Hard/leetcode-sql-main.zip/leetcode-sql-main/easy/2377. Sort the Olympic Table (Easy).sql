SELECT *
FROM olympic_2377
ORDER BY gold_medals DESC,silver_medals DESC,bronze_medals DESC,country ASC;
