SELECT TO_CHAR(day,'Day, Month DD, YYYY') AS day
FROM days_1853;
