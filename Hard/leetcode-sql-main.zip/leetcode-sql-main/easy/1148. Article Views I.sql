SELECT DISTINCT author_id
FROM views_1148
WHERE viewer_id = author_id;
