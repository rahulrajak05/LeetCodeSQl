SELECT email
FROM person_182 
GROUP BY email 
HAVING cnt>2;
