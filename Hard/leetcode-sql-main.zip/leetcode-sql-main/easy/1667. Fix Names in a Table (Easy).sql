SELECT user_id,INITCAP(name)
FROM users_1667
ORDER BY user_id;
