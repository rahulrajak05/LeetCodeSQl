SELECT teacher_id,COUNT(DISTINCT subject_id)
FROM teacher_2356
GROUP BY teacher_id;

