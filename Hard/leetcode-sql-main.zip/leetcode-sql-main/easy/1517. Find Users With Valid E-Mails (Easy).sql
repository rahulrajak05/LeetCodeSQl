SELECT *
FROM users_1517
WHERE mail SIMILAR TO '[a-zA-Z][a-zA-Z0-9_.-]*@leetcode[.]com';
