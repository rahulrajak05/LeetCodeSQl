SELECT product_id
FROM products_1757
WHERE low_fats = 'Y' AND recyclable = 'Y';
