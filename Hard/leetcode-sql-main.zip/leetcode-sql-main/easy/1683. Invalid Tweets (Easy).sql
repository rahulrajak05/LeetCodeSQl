SELECT tweet_id
FROM tweets_1683
WHERE LENGTH(content)>15;
