SELECT name,population,area
FROM world_595
WHERE area > 3000000 OR population > 25000000;
