SELECT customer_id
FROM customers_1821
WHERE year = 2021 AND revenue > 0;
